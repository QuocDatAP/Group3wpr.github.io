<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <?php wp_head(); ?>
    <title>Document</title>
</head>

<body <?php body_class(); ?>>
    <header class="site-header">
        <div class="container">
            <h1 class="school-logo-text float-left">
                <a href=""><?php the_custom_logo() ?></a>
            </h1>
            <span class="js-search-trigger site-header__search-trigger"><i class="fa fa-search"
                    aria-hidden="true"></i></span>
            <i class="site-header__menu-trigger fa fa-bars" aria-hidden="true"></i>
            <div class="site-header__menu group">
                <nav class="main-navigation">
                    <ul>
                        <?php
                wp_nav_menu(array(
                  'theme_location' => 'headerMenuLocation'
                ));
              ?>
                    </ul>
                </nav>
                <div class="site-header__util">
                <!--Custom cart start-->
               
                <a class="cart-contents" href="<?php echo wc_get_cart_url(); ?>"
                   title="<?php _e('Cart View', 'woothemes'); ?>">
                    <?php echo sprintf(_n('%d item', '%d items',  WC()->cart->cart_contents_count, 'woothemes'),
                    WC()->cart->cart_contents_count);?>  -
                    <?php echo  WC()->cart->get_cart_total(); ?>
                </a>
                <!--Custom cart end-->
                    <a href="#" class="btn btn-danger">Login</a>
                    <a href="#" class="btn btn-danger">Sign Up</a>
                </div>
            </div>
        </div>
        <?php do_action('nhom3_get_posts')?>
    </header>