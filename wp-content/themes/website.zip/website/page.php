<?php get_header() ?>
<div class="page-banner" >
    <div class="page-banner__bg-image" style="background-image: url('<?php echo get_theme_file_uri('images/ocean.jpg') ?>') " ></div>
    <div class="page-banner__content container container--narrow">
        <h1 class="page-banner__title"> <?php the_title() ?></h1>
        <div class="page-banner__intro">
            <p>Learn how the school of your dreams got started.</p>
        </div>
    </div>
</div>
<div class="container container--narrow page-section">
    <?php
    $parent_id = wp_get_post_parent_id(get_the_ID());
    if (is_page() && $parent_id > 0) {
    ?>
        <div class="metabox metabox--position-up metabox--with-home-link">
            <p>
                <a class="metabox__blog-home-link" href="echo site_url('/about-us') "><i class="fa fa-home" aria-hidden="true"></i> Back to About
                    Us</a> <a href="echo site_url('/our-history')"><span class="metabox__main">Our History</span></a>
            </p>
        </div>
    <?php } ?>
    <div class="page-links" style="list-style: none; ">
        <h2 class="page-links__title"><a href="<?php echo site_url('/about-us') ?>">About Us</a></h2>
        <?php
        $theParent = wp_get_post_parent_id(get_the_ID());
        if ($theParent) {
            $findChildOf = $theParent;
        } else {
            $findChildOf = get_the_ID();
        }
        wp_list_pages(array(
            'child_of' => $findChildOf,
            'title_li' => NULL
        ));
        ?>
    </div>
    <div class="container">
        <?php
        while (have_posts()) {
            the_post();
        ?>
            <p class="content"><?php the_content() ?></p>
        <?php
        }
        ?>
    </div>
</div>
<?php get_footer() ?>