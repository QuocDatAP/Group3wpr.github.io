<?php

function my_theme_support()
{
    add_theme_support('post-thumbnails');
    add_theme_support('woocommerce', array(
        "thumbnail_image_width" => 300,
        "single_image_width" => 300,
        "product_grid" => array(
            "default_columns" => "7",
            "min_columns" => "2",
            "max_columns" => "3",

        )
    ));
    add_theme_support('title-tag');
    register_nav_menu('headerMenuLocation', 'Header Menu Location ');
    register_nav_menu('footerLocation1', 'Footer Menu 1 ');
    register_nav_menu('footerLocation2', 'Footer Menu 2 ');

    add_theme_support('custom-logo', array(
        'width' => 100,
        'height' => 100,
        'flex-width' => true,
    ));
    //product thumbnail effect support
    add_theme_support("wc-product-gallery-zoom");
    add_theme_support("wc-product-gallery-lightbox");
    add_theme_support("wc-product-gallery-slider");
}

add_action('after_setup_theme', 'my_theme_support');
function university_files()
{
    
    wp_enqueue_style("style", get_stylesheet_uri(),array() ,"1.0","all");
    wp_enqueue_style('main_style', get_theme_file_uri('/build/index.css'));
    wp_enqueue_style('second_style', get_theme_file_uri('/build/style-index.css'));
    wp_enqueue_script('my-script', get_theme_file_uri('/build/index.js'),  array('jquery'), '1.0', true);
    wp_enqueue_style('bootstrap-1', 'https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css', array(), null);
    wp_enqueue_style('bootstrap-font', 'https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700,700i|Roboto:100,300,400,400i,700,700i');
    wp_enqueue_style('font-awesome', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(), null);
}
add_action('wp_enqueue_scripts', 'university_files');

function nhom3_get_posts($query)
{
    if ($query->is_home() && $query->is_main_query())
        $query->set('orderby', 'rand');
}
add_action('pre_get_posts', 'nhom3_get_posts');

add_filter('the_content_feed', 'filter_the_content_feed', 10, 2);

function filter_the_content_feed($content, $feed_type)
{
    // Kiểm tra xem chúng ta có đang trong vòng lặp chính trong một Bài viết không.
    if (is_singular() && in_the_loop() && is_main_query()) {
        return $content . esc_html__('Tôi đang lọc nội dung cho feed', 'wporg');
    }
    return $content;
}


function group3_content_filter($content)
{
    $find = 'Lorem';
    $replacement = '<strong style ="color: red; font-size:30px;" >Lorem</strong>';
    $content = str_replace($find, $replacement, $content);
    return $content;
}
add_filter('the_content', 'group3_content_filter');

function simple_bootstrap_theme_add_anchor_links($classes,$item, $args){
    $classes['class'] = "nav-link sbt-link-class";
    return $classes;
}
add_filter("nav_menu_link_attributes","simple_bootstrap_theme_add_anchor_links",1,10);


include_once 'include/wc-modifications.php';

function wpdocs_after_setup_theme() {
	add_theme_support( 'html5', array( 'search-form' ) );
}
add_action( 'after_setup_theme', 'wpdocs_after_setup_theme' );

 

/**
 * Show cart contents / total Ajax
 */
add_filter( 'woocommerce_add_to_cart_fragments', 'woocommerce_header_add_to_cart_fragment' );

function woocommerce_header_add_to_cart_fragment( $fragments ) {
	global $woocommerce;
    
	ob_start();

	?>
	 <a class="cart-contents" href="<?php echo $woocommerce->cart->get_cart_url(); ?>" title="<?php _e('View   cart', 'woothemes'); ?>"><?php echo sprintf(_n('%d item', '%d items', $woocommerce->cart->cart_contents_count, 'woothemes'), $woocommerce->cart->cart_contents_count);?> - <?php echo $woocommerce->cart->get_cart_total(); ?></a>
	<?php
	$fragments['a.cart-contents'] = ob_get_clean();
	return $fragments;
}

/**
 * Default WooCommerce Cart Hooks (just an example, do not copy)
 *
 */


